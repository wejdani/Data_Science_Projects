## _______ Wejdan Al-Ahmadi _______##

# Multiple Linear Regression
# ------------------------------------------Libraries------------------------------------------ #
#install.packages('caTools')
library(caTools)
# --------------------------------------------------------------------------------------------- #

# ---------------------------------------- data import ---------------------------------------- # 
setwd("C:/Users/wejda/Desktop/DS_Bootcamp/Week 11/Day 53")
dataset = read.csv('./data/boston.csv')
View(dataset)
# --------------------------------------------------------------------------------------------- #

# ---------------------------------------- data split ---------------------------------------- # 
# Splitting the dataset into the Training set and Test set
set.seed(123)
split = sample.split(dataset$target, SplitRatio = 0.8)
training_set = subset(dataset, split == TRUE)
test_set = subset(dataset, split == FALSE)

View(training_set)
View(test_set)
# -------------------------------------------------------------------------------------------- #


# ----------------------- 1) Multi Linear Regression on all features ------------------------- # 
regressor = lm(formula = target ~ .,
               data = training_set)

summary(regressor)

# To get the coefficients 
regressor$coefficients

# Predicting the Test set results
y_pred <- predict(regressor, newdata = test_set)
y_pred
y_actual <- test_set$target

error <- y_pred - test_set$target 
percent_error <- abs(error)/y_pred

percent_error <- round(percent_error,2)

df_all_features <- data.frame(y_pred, y_actual, error, percent_error)
View(df_all_features)

# R2 square function to calculate the R2 cost
rsq <- function (x, y) cor(x, y) ^ 2

all_features_R2 <- rsq(y_actual,y_pred)
print(paste0("The R2 Score for the multi linear regression model using all features is: ",all_features_R2))

# -------------------------------------------------------------------------------------------- #

# -------------------- 2) Multi Linear Regression on 2 & 3 star features --------------------- # 

# Now we will build our model with all the features that are 2 and 3 stars

# starred features
TAX <- dataset$TAX
B <- dataset$B
CRIM <- dataset$CRIM
ZN <- dataset$ZN
CHAS <- dataset$CHAS
NOX <- dataset$NOX
RM <- dataset$RM
DIS <- dataset$DIS
RAD <- dataset$RAD
PTRATIO <- dataset$PTRATIO
LSTAT <- dataset$LSTAT
# target to predict 
target <- dataset$target

all_star_dataset <- data.frame(CRIM, ZN, CHAS, NOX, RM, DIS, RAD, TAX, PTRATIO, B, LSTAT, target)

View(all_star_dataset)

set.seed(123)

split = sample.split(all_star_dataset$target, SplitRatio = 0.8)
all_star_training_set = subset(all_star_dataset, split == TRUE)
all_star_test_set = subset(all_star_dataset, split == FALSE)

View(all_star_training_set)
View(all_star_test_set)

all_star_regressor = lm(formula = target ~ .,
                      data = all_star_training_set)

summary(all_star_regressor)

all_star_y_pred <- predict(all_star_regressor, newdata = all_star_test_set)
all_star_y_pred


all_star_error <- all_star_y_pred - all_star_test_set$target
all_star_percent_error <- abs(all_star_error)/all_star_y_pred

all_star_percent_error <- round(all_star_percent_error,2)

comparison_df_1 <- data.frame(df_all_features, all_star_y_pred,all_star_error, all_star_percent_error)
View(comparison_df_1)

all_stars_features_R2 <- rsq(all_star_test_set$target,all_star_y_pred)
all_stars_features_R2

print(paste0("The R2 Score for the multi linear regression model using all features is: ",all_stars_features_R2))

# -------------------------------------------------------------------------------------------- #

# --------------------- 3) Multi Linear Regression on 2 star features ------------------------ # 
two_star_regressor = lm(formula = target ~ CRIM+ZN+CHAS+TAX+B,
                        data = all_star_training_set)

summary(all_star_regressor)
summary(two_star_regressor) # 

two_star_y_pred <- predict(two_star_regressor, newdata = all_star_test_set)
two_star_y_pred


two_star_error <- two_star_y_pred - all_star_test_set$target
two_star_percent_error <- abs(two_star_error)/two_star_y_pred

two_star_percent_error <- round(two_star_percent_error,2)

comparison_df_2 <- data.frame(comparison_df_1, two_star_y_pred,two_star_error, two_star_percent_error)
View(comparison_df_2)

two_stars_features_R2 <- rsq(all_star_test_set$target,two_star_y_pred)
two_stars_features_R2
print(paste0("The R2 Score for the multi linear regression model using all features is: ",two_stars_features_R2))

# --------------------- 3) Multi Linear Regression on 3 star features ------------------------ # 

three_star_regressor = lm(formula = target ~ NOX+RM+DIS+RAD+PTRATIO+LSTAT,
                        data = all_star_training_set)


summary(three_star_regressor)  # I notice here the star values changed and RAD is now useless compared to other features

three_star_y_pred <- predict(three_star_regressor, newdata = all_star_test_set)
three_star_y_pred


three_star_error <- three_star_y_pred - all_star_test_set$target
three_star_percent_error <- abs(three_star_error)/three_star_y_pred

three_star_percent_error <- round(three_star_percent_error,2)

comparison_df_3 <- data.frame(comparison_df_2, three_star_y_pred,three_star_error, three_star_percent_error)
View(comparison_df_3)

three_stars_features_R2 <- rsq(all_star_test_set$target,three_star_y_pred)
three_stars_features_R2
print(paste0("The R2 Score for the multi linear regression model using all features is: ",three_stars_features_R2))
# -------------------------------------------------------------------------------------------- #


# --------------------- 4) Multi Linear Regression on 3 star features(without RAD feature) ------------------------ #

three_star_regressor2 = lm(formula = target ~ NOX+RM+DIS+PTRATIO+LSTAT,
                          data = all_star_training_set)


summary(three_star_regressor2)  

three_star_y_pred2 <- predict(three_star_regressor2, newdata = all_star_test_set)
three_star_y_pred2


three_star_error2 <- three_star_y_pred2 - all_star_test_set$target
three_star_percent_error2 <- abs(three_star_error2)/three_star_y_pred2

three_star_percent_error2 <- round(three_star_percent_error2,2)

comparison_df_4 <- data.frame(comparison_df_2, three_star_y_pred2,three_star_error2, three_star_percent_error2)
View(comparison_df_4)

three_stars_features_R2_2 <- rsq(all_star_test_set$target,three_star_y_pred2)
three_stars_features_R2_2
print(paste0("The R2 Score for the multi linear regression model using all features is: ",three_stars_features_R2_2))

# ------------------------------------------------------------------------------------------------------------------ #


# The important features deemed by R with their ratings
stars <- c(2,2,2,2,2,3,3,3,3,3,3)
features <- c('TAX','B','CRIM','ZN','CHAS','NOX','RM','DIS','RAD','PTRATIO','LSTAT')
imp_features <- data.frame(features,stars)

print("The important features deemed by R with their ratings:")
print(imp_features)

# ---------------------------------------------------- RESULTS ------------------------------------------------ #

models<-c("All Features", "2 and 3 * Features", "2 * Features", "3 * Features", "3 * Features - 'RAD'")
R2_scores <- c(all_features_R2,all_stars_features_R2,two_stars_features_R2,three_stars_features_R2,three_stars_features_R2_2)
results <- data.frame(models,R2_scores)
print("The Results are:")
print(results)
maxx<-results[which.max(results$R2_scores),]
print(paste0("The best result is model: ", maxx$models, " With an R2 Score of: ",maxx$R2_scores))
